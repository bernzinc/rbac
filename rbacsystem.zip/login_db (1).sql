-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 13, 2025 at 12:33 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `login_history`
--

CREATE TABLE `login_history` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `login_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `role_name` varchar(100) NOT NULL,
  `permissions` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `role_name`, `permissions`, `created_at`) VALUES
(1, 'Admin', 'create,read,update,delete', '2025-06-22 14:26:30'),
(2, 'Staff', 'read,update,delete', '2025-06-22 14:27:08');

-- --------------------------------------------------------

--
-- Table structure for table `system_logs`
--

CREATE TABLE `system_logs` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `status` varchar(20) NOT NULL,
  `timestamp` datetime NOT NULL,
  `user_created_at` datetime DEFAULT NULL,
  `action` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `ip_address` varchar(50) DEFAULT NULL,
  `account_status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `system_logs`
--

INSERT INTO `system_logs` (`id`, `username`, `status`, `timestamp`, `user_created_at`, `action`, `description`, `ip_address`, `account_status`) VALUES
(127, 'admin', 'Success', '2025-07-11 07:02:31', '2025-06-22 18:08:22', 'Login', 'User logged in successfully', '::1', 'Active'),
(128, 'admin', 'Success', '2025-07-11 07:17:29', '2025-06-22 18:08:22', 'Login', 'User logged in successfully', '::1', 'Active'),
(129, 'admin', 'Success', '2025-07-11 07:17:42', '2025-06-22 18:08:22', 'Login', 'User logged in successfully', '::1', 'Active'),
(130, 'admin', 'Success', '2025-07-11 08:29:57', '2025-06-22 18:08:22', 'Login', 'User logged in successfully', '::1', 'Active'),
(131, 'admin', 'Success', '2025-07-11 08:36:14', '2025-06-22 18:08:22', 'Login', 'User logged in successfully', '::1', 'Active'),
(132, 'admin', 'Success', '2025-07-11 08:46:12', '2025-06-22 18:08:22', 'Login', 'User logged in successfully', '::1', 'Active'),
(133, 'admin', 'Success', '2025-07-11 09:46:46', '2025-06-22 18:08:22', 'Login', 'User logged in successfully', '::1', 'Active'),
(134, 'admin', 'Success', '2025-07-13 04:21:09', '2025-06-22 18:08:22', 'Login', 'User logged in successfully', '::1', 'Active'),
(135, 'Admin', 'Success', '2025-07-13 04:22:50', '2025-06-22 18:08:22', 'Edit User', 'Updated user \'bernz\': no changes', '::1', 'Active'),
(136, 'staff', 'Failed', '2025-07-13 04:23:06', NULL, 'Login', 'User not found', '::1', 'Active'),
(137, 'admin', 'Success', '2025-07-13 04:23:27', '2025-06-22 18:08:22', 'Login', 'User logged in successfully', '::1', 'Active'),
(138, 'bernz', 'Success', '2025-07-13 04:23:43', '2025-07-11 11:37:29', 'Login', 'User logged in successfully', '::1', 'Active'),
(139, 'admin', 'Success', '2025-07-13 05:50:23', '2025-06-22 18:08:22', 'Login', 'User logged in successfully', '::1', 'Active'),
(140, 'bernz', 'Success', '2025-07-13 05:51:15', '2025-07-11 11:37:29', 'Login', 'User logged in successfully', '::1', 'Active'),
(141, 'admin', 'Success', '2025-07-13 05:53:07', '2025-06-22 18:08:22', 'Login', 'User logged in successfully', '::1', 'Active'),
(142, 'admin', 'Success', '2025-07-13 06:43:07', '2025-06-22 18:08:22', 'Login', 'User logged in successfully', '::1', 'Active'),
(143, 'admin', 'Success', '2025-07-13 09:59:43', '2025-06-22 18:08:22', 'Login', 'User logged in successfully', '::1', 'Active'),
(144, 'admin', 'Success', '2025-07-13 10:00:08', '2025-06-22 18:08:22', 'Login', 'User logged in successfully', '::1', 'Active'),
(145, 'bernz', 'Success', '2025-07-13 10:00:23', '2025-07-11 11:37:29', 'Login', 'User logged in successfully', '::1', 'Active'),
(146, 'admin', 'Success', '2025-07-13 10:01:29', '2025-06-22 18:08:22', 'Login', 'User logged in successfully', '::1', 'Active'),
(147, 'Admin', 'Success', '2025-07-13 10:01:40', '2025-06-22 18:08:22', 'Edit User', 'Updated user \'bernz\': no changes', '::1', 'Active'),
(148, 'bernz', 'Success', '2025-07-13 10:01:51', '2025-07-11 11:37:29', 'Login', 'User logged in successfully', '::1', 'Active'),
(149, 'admin', 'Success', '2025-07-13 10:02:07', '2025-06-22 18:08:22', 'Login', 'User logged in successfully', '::1', 'Active'),
(150, 'admin', 'Success', '2025-07-13 10:04:38', '2025-06-22 18:08:22', 'Login', 'User logged in successfully', '::1', 'Active'),
(151, 'bernz', 'Success', '2025-07-13 10:05:15', '2025-07-11 11:37:29', 'Login', 'User logged in successfully', '::1', 'Active'),
(152, 'admin', 'Success', '2025-07-13 10:05:31', '2025-06-22 18:08:22', 'Login', 'User logged in successfully', '::1', 'Active'),
(153, 'Admin', 'Success', '2025-07-13 10:07:11', '2025-06-22 18:08:22', 'Delete User', 'Deleted user \'bernz\' (ID: 22)', '::1', 'Active'),
(154, 'Admin', 'Success', '2025-07-13 10:07:17', NULL, 'Delete User', 'Deleted user \'Admin\' (ID: 3)', '::1', 'Active'),
(155, 'Admin', 'Success', '2025-07-13 10:08:13', '2025-07-13 16:08:13', 'Create User', 'Created new user \'admin\' with role \'admin\' and permissions: create,read,update,delete', '::1', 'Active'),
(156, 'Admin', 'Success', '2025-07-13 10:08:40', '2025-07-13 16:08:13', 'Create User', 'Created new user \'staff\' with role \'staff\' and permissions: ', '::1', 'Active'),
(157, 'staff', 'Success', '2025-07-13 10:08:57', '2025-07-13 16:08:40', 'Login', 'User logged in successfully', '::1', 'Active'),
(158, 'admin', 'Success', '2025-07-13 10:09:14', '2025-07-13 16:08:13', 'Login', 'User logged in successfully', '::1', 'Active'),
(159, 'admin', 'Success', '2025-07-13 10:09:22', '2025-07-13 16:08:13', 'Edit User', 'Updated user \'staff\': no changes', '::1', 'Active'),
(160, 'staff', 'Success', '2025-07-13 10:09:52', '2025-07-13 16:08:40', 'Login', 'User logged in successfully', '::1', 'Active'),
(161, 'admin', 'Failed', '2025-07-13 10:50:41', '2025-07-13 16:08:13', 'Login', 'Invalid password attempt', '::1', 'Active'),
(162, 'admin', 'Success', '2025-07-13 10:50:49', '2025-07-13 16:08:13', 'Login', 'User logged in successfully', '::1', 'Active'),
(163, 'admin', 'Failed', '2025-07-13 10:51:14', '2025-07-13 16:08:13', 'Login', 'Invalid password attempt', '::1', 'Active'),
(164, 'admin', 'Success', '2025-07-13 10:51:22', '2025-07-13 16:08:13', 'Login', 'User logged in successfully', '::1', 'Active'),
(165, 'admin', 'Success', '2025-07-13 12:19:15', '2025-07-13 16:08:13', 'Login', 'User logged in successfully', '::1', 'Active'),
(166, 'staff', 'Failed', '2025-07-13 12:19:35', '2025-07-13 16:08:40', 'Login', 'Invalid password attempt', '::1', 'Active'),
(167, 'bernz', 'Failed', '2025-07-13 12:19:46', NULL, 'Login', 'User not found', '::1', 'Active'),
(168, 'staff', 'Failed', '2025-07-13 12:19:54', '2025-07-13 16:08:40', 'Login', 'Invalid password attempt', '::1', 'Active'),
(169, 'admin', 'Success', '2025-07-13 12:22:04', '2025-07-13 16:08:13', 'Login', 'User logged in successfully', '::1', 'Active'),
(170, 'admin', 'Success', '2025-07-13 12:22:24', '2025-07-13 16:08:13', 'Edit User', 'Updated user \'staff\': password updated', '::1', 'Active'),
(171, 'staff', 'Success', '2025-07-13 12:22:36', '2025-07-13 16:08:40', 'Login', 'User logged in successfully', '::1', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','staff') NOT NULL,
  `created_by` varchar(255) DEFAULT 'System',
  `created_at` datetime DEFAULT current_timestamp(),
  `permissions` varchar(255) DEFAULT NULL,
  `failed_attempts` int(11) DEFAULT 0,
  `last_failed_login` datetime DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `deactivation_date` datetime DEFAULT NULL,
  `otp_secret` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `created_by`, `created_at`, `permissions`, `failed_attempts`, `last_failed_login`, `status`, `deactivation_date`, `otp_secret`) VALUES
(23, 'admin', '$2y$10$xv/GB8DGyP0fIl4CuK3w7OJy5aebIdVIZfvIMyej/4jApe2pQeKXG', 'admin', 'Admin', '2025-07-13 16:08:13', 'create,read,update,delete', 0, NULL, 'active', NULL, NULL),
(24, 'staff', '$2y$10$p83JLOazFw.kogN4xSLATuzp8TwUwwFRCVSOpwrheVbD3DAIqrGXS', 'staff', 'Admin', '2025-07-13 16:08:40', 'read', 0, NULL, 'active', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login_history`
--
ALTER TABLE `login_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_logs`
--
ALTER TABLE `system_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login_history`
--
ALTER TABLE `login_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `system_logs`
--
ALTER TABLE `system_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=172;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `login_history`
--
ALTER TABLE `login_history`
  ADD CONSTRAINT `login_history_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
