<?php
session_start();
include 'db.php';
$id = $_GET['id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $role = $_POST['role'];
    $permissions = isset($_POST['permissions']) ? implode(',', $_POST['permissions']) : '';
    
    // Password change handling
    $passwordChanged = false;
    if (!empty($_POST['new_password']) && !empty($_POST['confirm_password'])) {
        if ($_POST['new_password'] === $_POST['confirm_password']) {
            $newPassword = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
            $passwordChanged = true;
        } else {
            $passwordError = "Passwords don't match!";
        }
    }

    // Prepare SQL based on whether password is being changed
    if ($passwordChanged) {
        $sql = "UPDATE users SET username = ?, role = ?, permissions = ?, password = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssi", $username, $role, $permissions, $newPassword, $id);
    } else {
        $sql = "UPDATE users SET username = ?, role = ?, permissions = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssi", $username, $role, $permissions, $id);
    }

if ($stmt->execute()) {
    // Fetch the updated user data for accurate change logging
    $result = $conn->query("SELECT * FROM users WHERE id = $id");
    $user = $result->fetch_assoc();
    $changes = [];
    if ($passwordChanged) $changes[] = "password updated";
    if ($username != $user['username']) $changes[] = "username from '{$user['username']}' to '{$username}'";
    if ($role != $user['role']) $changes[] = "role from '{$user['role']}' to '{$role}'";
    if ($permissions != $user['permissions']) $changes[] = "permissions from '{$user['permissions']}' to '{$permissions}'";
    $description = "Updated user '{$user['username']}': " . (count($changes) ? implode(', ', $changes) : 'no changes');
    $currentUser = isset($_SESSION['username']) ? $_SESSION['username'] : 'system';
    log_action($conn, $currentUser, 'Success', 'Edit User', $description);
    header("Location: dashboard.php");
    exit();
} else {
    // Log the failure
    $currentUser = isset($_SESSION['username']) ? $_SESSION['username'] : 'system';
    log_action($conn, $currentUser, 'Failed', 'Edit User', "Failed to update user '{$username}': " . $conn->error);
    echo "Error: " . $conn->error;
}
}

$result = $conn->query("SELECT * FROM users WHERE id = $id");
$user = $result->fetch_assoc();
$existingPermissions = explode(',', $user['permissions']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Employee | Employee Monitoring System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #4361ee;
            --dark: #212529;
            --light: #f8f9fa;
            --gray: #6c757d;
            --gray-light: #e9ecef;
            --danger: #dc3545;
            --success: #28a745;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background: url('public/images/bg.jpg') no-repeat center center fixed;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            padding: 1rem;
        }
        
        .card {
            background: #fff;
            color: #222;
            border-radius: 16px;
            box-shadow: 0 8px 32px 0 #4361ee55, 0 1.5px 8px 0 #0008;
            padding: 2rem;
            width: 100%;
            max-width: 500px;
            animation: slideIn 0.4s ease;
            border: 1.5px solid #4361ee33;
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .card-title {
            font-size: 1.7rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
            text-align: center;
            color: #37433bff;
            letter-spacing: 1px;
            text-shadow: 0 4px 24px #4361ee22, 0 1px 0 #2221;
            position: relative;
            z-index: 1;
        }
        .card-title::after {
            content: none;
        }
        
        .form-group {
            margin-bottom: 1.25rem;
            width: 95%
        }
        
        .form-label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
        }
        
        .form-control {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            font-size: 0.95rem;
            background-color: rgba(255, 255, 255, 0.05);
            color: #000;
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.3);
        }
        
        .checkbox-group {
            display: flex;
            flex-wrap: wrap;
            gap: 0.75rem;
            margin-top: 0.5rem;
        }
        
        .checkbox-item {
            display: flex;
            align-items: center;
            font-size: 0.9rem;
        }
        
        .checkbox-item input {
            margin-right: 0.5rem;
        }
        
        .checkbox-item input:checked {
            accent-color: #6D8474;
        }
        
        .checkbox-item input:focus {
            outline: none;
            box-shadow: 0 0 0 2px #6D847444;
            border-radius: 4px;
        }
        
        .btn {
            width: 100%;
            padding: 0.75rem;
            border-radius: 8px;
            font-weight: 500;
            cursor: pointer;
            border: none;
            background-color: #6D8474;
            color: white;
            margin-top: 0.5rem;
            transition: background-color 0.2s;
        }
        
        .btn:hover {
            background-color: #596a5fff;
        }
        
        .back-link {
            display: block;
            text-align: center;
            margin-top: 1rem;
            color: rgba(0, 0, 0, 0.7);
            font-size: 0.9rem;
            text-decoration: none;
        }
        
        .back-link:hover {
            color:gray;
            text-decoration: underline;
        }
        
        .password-toggle {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: var(--gray);
        }
        
        .password-field {
            position: relative;
        }
        
        .error-message {
            color: var(--danger);
            font-size: 0.85rem;
            margin-top: 0.25rem;
        }
        
        .success-message {
            color: var(--success);
            font-size: 0.85rem;
            margin-top: 0.25rem;
        }
        
        .section-title {
            font-size: 1.1rem;
            margin: 1.5rem 0 0.75rem;
            padding-bottom: 0.5rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
    </style>
</head>
<body>
    <div class="card">
        <h2 class="card-title">Edit Staff</h2>
        
        <form method="POST">
            <div class="form-group">
                <label for="username" class="form-label">Username</label>
                <input type="text" id="username" name="username" class="form-control" 
                       value="<?= htmlspecialchars($user['username']) ?>" required>
            </div>
            
            <div class="form-group">
                <label for="role" class="form-label">Role</label>
                <select id="role" name="role" class="form-control" required>
                    <option value="admin" <?= $user['role'] == 'admin' ? 'selected' : '' ?>>Admin</option>
                    <option value="staff" <?= $user['role'] == 'staff' ? 'selected' : '' ?>>Staff</option>
                </select>
            </div>
            
            <div class="form-group">
                <label class="form-label">Permissions</label>
                <div class="checkbox-group">
                    <label class="checkbox-item">
                        <input type="checkbox" name="permissions[]" value="create" <?= in_array('create', $existingPermissions) ? 'checked' : '' ?>> Create
                    </label>
                    <label class="checkbox-item">
                        <input type="checkbox" name="permissions[]" value="read" <?= in_array('read', $existingPermissions) ? 'checked' : '' ?>> Read
                    </label>
                    <label class="checkbox-item">
                        <input type="checkbox" name="permissions[]" value="update" <?= in_array('update', $existingPermissions) ? 'checked' : '' ?>> Update
                    </label>
                    <label class="checkbox-item">
                        <input type="checkbox" name="permissions[]" value="delete" <?= in_array('delete', $existingPermissions) ? 'checked' : '' ?>> Delete
                    </label>
                </div>
            </div>
            
            <h3 class="section-title">Change Password</h3>
            <div class="form-group">
                <label for="new_password" class="form-label">New Password</label>
                <div class="password-field">
                    <input type="password" id="new_password" name="new_password" class="form-control" 
                           placeholder="Leave blank to keep current password">
                    <span class="password-toggle" onclick="togglePassword('new_password')">
                       
                    </span>
                </div>
            </div>
            
            <div class="form-group">
                <label for="confirm_password" class="form-label">Confirm Password</label>
                <div class="password-field">
                    <input type="password" id="confirm_password" name="confirm_password" class="form-control" 
                           placeholder="Confirm new password">
                    <span class="password-toggle" onclick="togglePassword('confirm_password')">
                       
                    </span>
                </div>
                <?php if (isset($passwordError)): ?>
                    <div class="error-message"><?= $passwordError ?></div>
                <?php endif; ?>
            </div>
            
            <button type="submit" class="btn">Update</button>
            <a href="view.php" class="back-link">Back to Users List</a>
        </form>
    </div>

    <!-- Font Awesome for eye icon -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>
    
    <script>
        function togglePassword(id) {
            const input = document.getElementById(id);
            const icon = input.nextElementSibling.querySelector('i');
            
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.replace('fa-eye', 'fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.replace('fa-eye-slash', 'fa-eye');
            }
        }
    </script>
</body>
</html>