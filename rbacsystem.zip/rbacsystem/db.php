<?php
$host = 'localhost';
$db = 'login_db';
$user = 'root';
$pass = ''; // default password is empty in XAMPP

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

// Function to log system events
function log_action($conn, $username, $status, $action, $description, $account_status = 'Active') {
    $timestamp = date('Y-m-d H:i:s');
    $ip_address = $_SERVER['REMOTE_ADDR'] ?? '::1';
    
    // Get user creation date if available
    $user_created_at = null;
    if ($username) {
        $stmt = $conn->prepare("SELECT created_at FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            $user_created_at = $user['created_at'];
        }
    }
    
    // Replace 'employee' with 'staff' in action and description
    $action = str_ireplace('staff', 'staff', $action);
    $description = str_ireplace('staff', 'staff', $description);
    
    $stmt = $conn->prepare("INSERT INTO system_logs 
                          (username, status, timestamp, user_created_at, action, description, ip_address, account_status) 
                          VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssss", $username, $status, $timestamp, $user_created_at, $action, $description, $ip_address, $account_status);
    $stmt->execute();
}
?>
