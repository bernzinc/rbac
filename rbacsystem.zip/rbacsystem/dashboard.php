<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

include 'db.php';

$username = $_SESSION['username'];

// Get user info
$stmt = $conn->prepare("SELECT id, role, permissions FROM users WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$current_user = $result->fetch_assoc();

$permissions = isset($current_user['permissions']) ? explode(',', $current_user['permissions']) : [];
$_SESSION['role'] = $current_user['role'];
$_SESSION['permissions'] = $permissions;
$_SESSION['user_id'] = $current_user['id'];

// Get all users for main table and sidebar
$users = $conn->query("SELECT * FROM users ORDER BY role DESC, username ASC");

// Get recent login activity - with error handling
$recent_logins_query = "
    SELECT u.username, u.role, MAX(l.login_time) as last_login 
    FROM users u
    LEFT JOIN login_history l ON u.id = l.user_id 
    GROUP BY u.id
    ORDER BY last_login DESC
    LIMIT 5
";

$recent_logins = $conn->query($recent_logins_query);
if (!$recent_logins) {
    // Fallback if login_history doesn't exist
    $recent_logins = $conn->query("
        SELECT username, role, last_login as last_login 
        FROM users 
        WHERE last_login IS NOT NULL
        ORDER BY last_login DESC
        LIMIT 5
    ") or die("Error getting login activity: " . $conn->error);
}

// Get summary counts for dashboard cards
$total_users = $conn->query("SELECT COUNT(*) as cnt FROM users")->fetch_assoc()['cnt'];
$total_activity_logs = $conn->query("SELECT COUNT(*) as cnt FROM login_history")->fetch_assoc()['cnt'];
$total_system_logs = $conn->query("SELECT COUNT(*) as cnt FROM system_logs")->fetch_assoc()['cnt'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Role Based Access Control</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
</head>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
@import url('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css');

:root {
    --primary:rgb(30, 134, 72);
    --danger: #ff3860;
    --success: #23d160;
    --warning: #ffdd57;
    --dark:rgb(47, 63, 62);
    --light: #f8f9fa;
    --border-radius: 12px;
    --shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
    --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Inter', sans-serif;
    background-image: url('public/images/bg.jpg');
    background-size: cover;
    background-repeat: no-repeat;
    background-attachment: fixed;
    color: #000;
    line-height: 1.6;
}

.dashboard {
    display: grid;
    grid-template-columns: 280px 1fr;
    min-height: 100vh;
}

.sidebar {
    background-color: var(--dark);
    color: rgba(255, 255, 255, 0.9);
    padding: 2rem 1.5rem;
    position: sticky;
    top: 0;
    height: 100vh;
    box-shadow: var(--shadow);
    display: flex;
    flex-direction: column;
    width: 280px;
    min-width: 220px;
    max-width: 320px;
    box-sizing: border-box;
    overflow-x: hidden;
}

.sidebar-header {
    display: flex;
    align-items: center;
    margin-bottom: 2rem;
}

.sidebar-header i {
    font-size: 1.5rem;
    margin-right: 0.75rem;
    color: var(--primary);
}

.sidebar-header h2 {
    font-weight: 600;
    font-size: 1.25rem;
    color: white;
}

.nav-menu {
    list-style: none;
    margin-bottom: 1rem;
}

.nav-item {
    margin-bottom: 0.5rem;
}

.nav-link {
    display: flex;
    align-items: center;
    padding: 0.75rem 1rem;
    color: rgba(255, 255, 255, 0.8);
    text-decoration: none;
    border-radius: var(--border-radius);
    transition: var(--transition);
}

.nav-link:hover, .nav-link.active {
    background-color: rgba(255, 255, 255, 0.1);
    color: white;
}

.nav-link i {
    margin-right: 0.75rem;
    width: 20px;
    text-align: center;
    color: rgba(255, 255, 255, 0.7);
}

.login-activity {
    margin-top: auto;
    background-color: rgba(0, 0, 0, 0.2);
    border-radius: var(--border-radius);
    padding: 1rem;
    max-height: 300px;
    overflow-y: auto;
}

.login-activity-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 1rem;
    color: white;
}

.login-activity-header h3 {
    font-size: 0.95rem;
    font-weight: 500;
}

.login-activity-header i {
    color: var(--primary);
}

.activity-list {
    list-style: none;
}

.activity-item {
    display: flex;
    align-items: center;
    padding: 0.75rem 0;
    border-bottom: 1px solid rgba(255, 255, 255, 0.05);
}

.activity-item:last-child {
    border-bottom: none;
}

.activity-avatar {
    width: 36px;
    height: 36px;
    border-radius: 50%;
    background-color: rgba(58, 134, 255, 0.2);
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 0.75rem;
    font-size: 0.85rem;
    color: var(--primary);
}

.activity-details {
    flex: 1;
}

.activity-user {
    font-size: 0.85rem;
    color: white;
    font-weight: 500;
    margin-bottom: 0.1rem;
    display: flex;
    align-items: center;
}

.activity-meta {
    display: flex;
    justify-content: space-between;
    font-size: 0.75rem;
    color: rgba(255, 255, 255, 0.5);
}

.activity-role {
    font-size: 0.7rem;
    background-color: rgba(255, 255, 255, 0.1);
    color: rgba(255, 255, 255, 0.8);
    padding: 0.2rem 0.5rem;
    border-radius: 50px;
}

.activity-time {
    font-size: 0.7rem;
    color: rgba(255, 255, 255, 0.6);
}

.online-indicator {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background-color: var(--success);
    margin-left: 0.5rem;
    display: inline-block;
}

.main-content {
    padding: 2rem;
}

.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;
}

.header h1 {
    font-weight: 700;
    font-size: 2.1rem;
    color: #222020cf;
    text-align: left;
    letter-spacing: 1px;
    text-shadow: 0 4px 24px #23d16055, 0 1px 0 #222;
    position: relative;
    z-index: 1;
}
.header h1::after {
    content: none;
}

.header h2 {
    color: #000 !important;
    margin-bottom: 0.5rem;
    text-shadow: 0 2px 12px #0001;
}

.btn {
    display: inline-flex;
    align-items: center;
    padding: 0.75rem 1.5rem;
    border-radius: var(--border-radius);
    font-weight: 500;
    text-decoration: none;
    transition: var(--transition);
    border: none;
    cursor: pointer;
    font-size: 0.9rem;
}

.btn i {
    margin-right: 0.5rem;
}

.btn-primary {
    background-color: var(--primary);
    color: white;
}

.btn-primary:hover {
    background-color:rgb(98, 164, 128);
    transform: translateY(-2px);
}

.btn-danger {
    background-color: var(--danger);
    color: white;
}

.btn-danger:hover {
    background-color: #e63256;
    transform: translateY(-2px);
}

.card {
    background: whitesmoke;
    color: #000;
    border-radius: var(--border-radius);
    padding: 1.5rem;
    margin-bottom: 1.5rem;
    box-shadow: 0 8px 32px 0 #3a86ff22, 0 1.5px 8px 0 #0002;
    border: 1.5px solid #3a86ff33;
}

.card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
    padding-bottom: 1rem;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}

.card-header h2 {
    font-weight: 600;
    font-size: 1.25rem;
    color: #000;
}
.card-header h2 i {
    color: #000;
}

.card-body {
    overflow-x: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th, td {
    padding: 1rem;
    text-align: left;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    color: rgba(0, 0, 0, 0.84);
}

th {
    font-weight: 500;
    color: #000;
    text-transform: uppercase;
    font-size: 0.75rem;
    letter-spacing: 0.5px;
}
tr {
    color: #000;
}

tr:hover td {
    background-color: rgba(255, 255, 255, 0.05);
}

.badge {
    display: inline-block;
    padding: 0.35rem 0.75rem;
    border-radius: 50px;
    font-size: 0.75rem;
    font-weight: 500;
}

.badge-primary {
    background-color: rgba(58, 134, 255, 0.2);
    color: var(--primary);
}

.badge-success {
    background-color: rgba(131, 209, 35, 0.2);
    color: var(--success);
}

.badge-warning {
    background-color: rgba(255, 221, 87, 0.2);
    color: #947600;
}

.badge-danger {
    background-color: rgba(255, 56, 96, 0.2);
    color: var(--danger);
}

.badge-circle {
    display: inline-block;
    width: 32px;
    height: 32px;
    border-radius: 50%;
    background-color: rgba(255, 221, 87, 0.2);
    color: #947600;
    text-align: center;
    line-height: 32px;
    font-size: 0.85rem;
    font-weight: 600;
    margin-right: 0.5rem;
}

.action-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 32px;
    height: 32px;
    border-radius: 50%;
    background-color: rgba(255, 255, 255, 0.1);
    color: white;
    margin-right: 0.5rem;
    transition: var(--transition);
    border: none;
    cursor: pointer;
}

.action-btn:hover {
    transform: translateY(-2px);
}

.action-btn.view {
    background-color: rgba(35, 209, 96, 0.2);
    color: var(--success);
}

.action-btn.edit {
    background-color: rgba(255, 221, 87, 0.2);
    color: #947600;
}

.action-btn.delete {
    background-color: rgba(255, 56, 96, 0.2);
    color: var(--danger);
}

.empty-state {
    text-align: center;
    padding: 3rem;
    color: #000;
}

.empty-state i {
    font-size: 3rem;
    margin-bottom: 1rem;
    opacity: 0.5;
    color: #000;
}

.empty-state h3 {
    font-weight: 500;
    margin-bottom: 0.5rem;
    color: #000;
}

.permissions-grid {
    display: flex;
    gap: 0.5rem;
    flex-wrap: wrap;
}

/* Scrollbar styling */
::-webkit-scrollbar {
    width: 6px;
}

::-webkit-scrollbar-track {
    background: rgba(255, 255, 255, 0.05);
    border-radius: 3px;
}

::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.2);
    border-radius: 3px;
}

::-webkit-scrollbar-thumb:hover {
    background: rgba(255, 255, 255, 0.3);
}

#sidebar-calendar {
    width: 100%;
    max-width: 240px;
    min-width: 0;
    box-sizing: border-box;
}

</style>
<body>
    <div class="dashboard">
        <aside class="sidebar">
            <div class="sidebar-header">
                <h2>DASHBOARD</h2>
            </div>
            <ul class="nav-menu">
                <li class="nav-item">
                    <a href="#" class="nav-link active">
                        <i class="fas fa-home"></i>
                        Home
                    </a>
                </li>
                <?php if ($_SESSION['role'] !== 'staff'): ?>
                <li class="nav-item">
                    <a href="view.php" class="nav-link">
                        <i class="fas fa-history"></i>
                        Activity Logs
                    </a>
                </li>
                <li class="nav-item">   
                    <a href="logs.php" class="nav-link">
                        <i class="fas fa-clipboard-list"></i>
                        System Logs
                    </a>
                </li>
                <li class="nav-item">
                    <a href="create.php" class="nav-link">
                        <i class="fas fa-plus"></i>
                        Add Staff
                    </a>
                </li>
                <?php else: ?>
                    <?php if (in_array('create', $permissions)): ?>
                        <li class="nav-item">
                            <a href="create.php" class="nav-link">
                                <i class="fas fa-plus"></i>
                                Add Staff
                            </a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>
            </ul>
            <div class="card" style="background:rgba(0,0,0,0.15); box-shadow:none; margin-bottom:1.5rem;">
                <div class="card-header" style="padding-bottom:0.5rem; margin-bottom:0.5rem; border-bottom:1px solid rgba(255,255,255,0.08);">
                    <h2 style="font-size:1rem; color:white;">Your Access Permissions</h2>
                </div>
                <div class="card-body" style="padding:0;">
                    <div class="permissions-grid">
                        <?php foreach ($permissions as $permission): ?>
                            <span class="badge 
                                <?= $permission == 'create' ? 'badge-primary' : '' ?>
                                <?= $permission == 'read' ? 'badge-success' : '' ?>
                                <?= $permission == 'update' ? 'badge-warning' : '' ?>
                                <?= $permission == 'delete' ? 'badge-danger' : '' ?>
                            ">
                                <?= htmlspecialchars($permission) ?>
                            </span>
                        <?php endforeach; ?>
                        <?php if (empty($permissions)): ?>
                            <span style="color: rgba(255, 255, 255, 0.6);">No special permissions</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <!-- Calendar Widget moved to dashboard main content -->
            <div style="margin-top: auto;">
                <a href="logout.php" class="nav-link">
                    <i class="fas fa-sign-out-alt"></i>
                    Logout
                </a>
            </div>
        </aside>
        
        <main class="main-content">

            <div class="header">
                <div>
                    <?php if ($_SESSION['role'] === 'admin'): ?>
                        <h2 style="color:#23d160; margin-bottom: 0.5rem; text-shadow:0 2px 12px #23d16044;">Welcome Admin</h2>
                    <?php else: ?>
                        <h2 style="color:#3a86ff; margin-bottom: 0.5rem; text-shadow:0 2px 12px #3a86ff44;">Welcome <?= htmlspecialchars($_SESSION['username']) ?></h2>
                    <?php endif; ?>
                    <h1>Role Based Access Control</h1>
                </div>
                <?php if (in_array('create', $permissions)): ?>
                   
                <?php endif; ?>
            </div>

            <!-- Dashboard Summary Cards -->
            <?php if ($_SESSION['role'] !== 'staff'): ?>
            <div style="display: flex; gap: 2rem; margin-bottom: 2rem; flex-wrap: wrap;">
                <?php
                    // Get counts for summary cards
                    $total_users = $conn->query("SELECT COUNT(*) as cnt FROM users")->fetch_assoc()['cnt'];
                    $total_system_logs = $conn->query("SELECT COUNT(*) as cnt FROM system_logs")->fetch_assoc()['cnt'];
                ?>
                <div style="flex:1; min-width:220px; background:white; border-radius:12px; box-shadow:0 4px 24px #3a86ff22, 0 1.5px 8px 0 #0002; padding:1.5rem; display:flex; align-items:center; gap:1rem; border:1.5px solid #3a86ff33;">
                    <div style="background:#3a86ff22; border-radius:50%; width:48px; height:48px; display:flex; align-items:center; justify-content:center;">
                        <i class="fas fa-users" style="font-size:1.5rem; color:#3a86ff;"></i>
                    </div>
                    <div>
                        <div style="font-size:2rem; font-weight:700; color:#222;"> <?= $total_users ?> </div>
                        <div style="font-size:1rem; color:#222;">Total Users</div>
                    </div>
                </div>
                <div style="flex:1; min-width:220px; background:white; border-radius:12px; box-shadow:0 4px 24px #ff386022, 0 1.5px 8px 0 #0002; padding:1.5rem; display:flex; align-items:center; gap:1rem; border:1.5px solid #ff386033;">
                    <div style="background:#ff386022; border-radius:50%; width:48px; height:48px; display:flex; align-items:center; justify-content:center;">
                        <i class="fas fa-clipboard-list" style="font-size:1.5rem; color:#ff3860;"></i>
                    </div>
                    <div>
                        <div style="font-size:2rem; font-weight:700; color:#222;"> <?= $total_system_logs ?> </div>
                        <div style="font-size:1rem; color:#222;">Total System Logs</div>
                    </div>
                </div>
            </div>
            <?php endif; ?>

           
            
            
            <?php if (in_array('read', $permissions)): ?>
                <div class="card">
                    <div class="card-header">
                        <h2><i class="fas fa-users-cog"></i> Users</h2>
                    </div>
                    <div class="card-body">
                        <?php 
                        $users_table = $conn->query("SELECT * FROM users ORDER BY role DESC, username ASC");
                        if ($users_table && $users_table->num_rows > 0): ?>
                            <table>
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Role</th>
                                        <th>Created At</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while($row = $users_table->fetch_assoc()): ?>
                                        <tr>
                                            <td><?= $row['id'] ?></td>
                                            <td><?= htmlspecialchars($row['username']) ?></td>
                                            <td>
                                                <?php if ($row['role'] == 'staff'): ?>
                                                    <span class="badge badge-primary">Staff</span>
                                                <?php else: ?>
                                                    <span class="badge 
                                                        <?= $row['role'] == 'admin' ? 'badge-primary' : '' ?>
                                                        <?= $row['role'] == 'staff' ? 'badge-warning' : '' ?>
                                                    ">
                                                        <?= htmlspecialchars(ucfirst($row['role'])) ?>
                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?= isset($row['created_at']) ? $row['created_at'] : 'N/A' ?></td>
                                            <td>
                                                <?php if (in_array('read', $permissions)): ?>
                                                    <a href="view_user.php?id=<?= $row['id'] ?>" class="action-btn view" title="View">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                <?php endif; ?>
                                                <?php if (in_array('update', $permissions)): ?>
                                                    <a href="edit.php?id=<?= $row['id'] ?>" class="action-btn edit" title="Edit">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                <?php endif; ?>
                                                <?php if (in_array('delete', $permissions)): ?>
                                                    <a href="delete.php?id=<?= $row['id'] ?>" class="action-btn delete" title="Delete">
                                                        <i class="fas fa-trash"></i>
                                                    </a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        <?php else: ?>
                            <div class="empty-state">
                                <i class="fas fa-user-slash"></i>
                                <h3>No Staff Found</h3>
                                <p>There are currently no staff in the system</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php else: ?>
                <div class="card">
                    <div class="empty-state">
                        <i class="fas fa-lock"></i>
                        <h3>Access Restricted</h3>
                        <p>You don't have permission to view staff data</p>
                    </div>
                </div>
            <?php endif; ?>

            
        </main>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/litepicker/dist/litepicker.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/litepicker/dist/litepicker.css" />
    <link rel="stylesheet" href="public/css/calendar.css" />
    <script>
    // Simple calendar using Litepicker
    document.addEventListener('DOMContentLoaded', function() {
        new Litepicker({
            element: document.getElementById('sidebar-calendar'),
            inlineMode: true,
            singleMode: true,
            numberOfMonths: 1,
            numberOfColumns: 1,
            format: 'YYYY-MM-DD',
            lang: 'en-US',
            showTooltip: false,
            dropdowns: {
                minYear: 2000,
                maxYear: 2100,
                months: true,
                years: true
            }
        });
    });
    // SweetAlert for Delete
    document.querySelectorAll('.action-btn.delete').forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const url = this.getAttribute('href');
            Swal.fire({
                title: 'Are you sure?',
                text: "This action cannot be undone!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = url;
                }
            });
        });
    });
    // SweetAlert for Logout
    document.querySelectorAll('a.nav-link[href="logout.php"]').forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            Swal.fire({
                title: 'Logout?',
                text: 'Are you sure you want to logout?',
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#aaa',
                confirmButtonText: 'Logout'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = 'logout.php';
                }
            });
        });
    });
    </script>
</body>
</html>