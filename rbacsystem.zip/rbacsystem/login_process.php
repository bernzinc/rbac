<?php
session_start();

include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'] ?? null;

    // Check if user is currently locked out
    if (isset($_SESSION['lockout_time']) && time() < $_SESSION['lockout_time']) {
        $_SESSION['error'] = "Too many failed attempts. Please wait before trying again.";
        header("Location: login.php");
        exit();
    }

    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            // Reset attempts on successful login
            if (isset($_SESSION['login_attempts'])) {
                unset($_SESSION['login_attempts']);
            }
            if (isset($_SESSION['lockout_time'])) {
                unset($_SESSION['lockout_time']);
            }
            $reset = $conn->prepare("UPDATE users SET failed_attempts = 0, last_failed_login = NULL WHERE id = ?");
            $reset->bind_param("i", $user['id']);
            $reset->execute();
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['permissions'] = explode(',', $user['permissions']);
            log_action($conn, $username, 'Success', 'Login', 'User logged in successfully');
            header("Location: dashboard.php");
            exit();
        } else {
            // Increment failed attempts
            if (!isset($_SESSION['login_attempts'])) {
                $_SESSION['login_attempts'] = 0;
            }
            $_SESSION['login_attempts']++;
            $update = $conn->prepare("UPDATE users SET failed_attempts = failed_attempts + 1, last_failed_login = NOW() WHERE id = ?");
            $update->bind_param("i", $user['id']);
            $update->execute();
            log_action($conn, $username, 'Failed', 'Login', 'Invalid password attempt');
            if ($_SESSION['login_attempts'] >= 3) {
                $_SESSION['lockout_time'] = time() + 60; // 1 minute lockout
                $_SESSION['error'] = "Too many failed attempts. Please wait 1 minute before trying again.";
            } else {
                $remaining = 3 - $_SESSION['login_attempts'];
                $_SESSION['error'] = "Invalid username or password. You have $remaining attempts remaining.";
            }
            header("Location: login.php");
            exit();
        }
    } else {
        // User not found, but we'll still count this as a failed attempt
        if (!isset($_SESSION['login_attempts'])) {
            $_SESSION['login_attempts'] = 0;
        }
        $_SESSION['login_attempts']++;
        log_action($conn, $username, 'Failed', 'Login', 'User not found');
        if ($_SESSION['login_attempts'] >= 3) {
            $_SESSION['lockout_time'] = time() + 60; // 1 minute lockout
            $_SESSION['error'] = "Too many failed attempts. Please wait 1 minute before trying again.";
        } else {
            $remaining = 3 - $_SESSION['login_attempts'];
            $_SESSION['error'] = "User not found. You have $remaining attempts remaining.";
        }
        header("Location: login.php");
        exit();
    }
} elseif (isset($_POST['otp'])) {
    $otp = $_POST['otp'];

    // Find user by OTP (loop through users with otp_secret)
    $stmt = $conn->query("SELECT id, username, role, permissions, otp_secret FROM users WHERE otp_secret IS NOT NULL");
    $found = false;
    while ($user = $stmt->fetch_assoc()) {
        $qrcodeprovider = new GoogleChartsQrCodeProvider();
        $tfa = new TwoFactorAuth($qrcodeprovider, 'RBAC System');
        if ($otp && $tfa->verifyCode($user['otp_secret'], $otp)) {
            // Successful OTP login
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['permissions'] = explode(',', $user['permissions']);
            log_action($conn, $user['username'], 'Success', 'Login', 'User logged in with OTP');
            header("Location: otp_container.php");
            exit();
        }
    }
    // If no match
    $_SESSION['error'] = "Invalid OTP code. Please try again.";
    header("Location: login.php?error=otp");
    exit();
}
?>