<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}
require 'db.php';
require_once 'vendor/robthree/twofactorauth/lib/TwoFactorAuth.php';

$username = $_SESSION['username'];

// Fetch user info
$stmt = $conn->prepare("SELECT id, username, role, otp_secret FROM users WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

$tfa = new \RobThree\Auth\TwoFactorAuth('RBAC System');
if ($user && $user['role'] === 'staff') {
    echo '<h2>2FA is not required for staff users.</h2>';
    exit();
} elseif (empty($user['otp_secret'])) {
    $secret = $tfa->createSecret();
    $qrCodeUrl = $tfa->getQRCodeImageAsDataUri($username, $secret);
    // Save secret to user in DB (after confirmation)
} else {
    $secret = $user['otp_secret'];
    $qrCodeUrl = $tfa->getQRCodeImageAsDataUri($username, $secret);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Setup Two-Factor Authentication</title>
</head>
<body>
    <h2>Setup Two-Factor Authentication (OTP)</h2>
    <p>Scan this QR code with your authenticator app:</p>
    <img src="<?= $qrCodeUrl ?>" alt="QR Code">
    <p>Or enter this secret manually: <strong><?= $secret ?></strong></p>
    <form method="post" action="save_otp.php">
        <input type="hidden" name="secret" value="<?= $secret ?>">
        <button type="submit">Enable 2FA</button>
    </form>
</body>
</html>
