<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
include 'db.php';

$username = $_SESSION['username'];

// Get user info for permissions check
$stmt = $conn->prepare("SELECT role, permissions FROM users WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

$permissions = isset($user['permissions']) ? explode(',', $user['permissions']) : [];

// Handle activation/deactivation
if (isset($_GET['action']) && in_array('update', $permissions)) {
    $userId = intval($_GET['id']);
    $action = $_GET['action'];
    
    if ($action === 'activate') {
        $conn->query("UPDATE users SET status = 'active', deactivation_date = NULL WHERE id = $userId");
    } elseif ($action === 'deactivate') {
        $deactivationDate = date('Y-m-d H:i:s', strtotime('+3 days'));
        $conn->query("UPDATE users SET status = 'inactive', deactivation_date = '$deactivationDate' WHERE id = $userId");
    }
    
    header("Location: view_user.php");
    exit();
}
$conn->query("UPDATE users SET status='inactive' WHERE deactivation_date <= NOW() AND status='active'");

// Check for accounts to delete (deactivated for more than 3 days)
$threeDaysAgo = date('Y-m-d H:i:s', strtotime('-3 days'));
$conn->query("DELETE FROM users WHERE status = 'inactive' AND deactivation_date <= '$threeDaysAgo'");

// Get all users
$users = $conn->query("SELECT * FROM users ORDER BY id ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RBAC |RBAC</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #3a86ff;
            --danger: #ff3860;
            --success: #23d160;
            --warning: #ffdd57;
            --dark: #1a1a1a;
            --light: #f8f9fa;
            --border-radius: 12px;
            --shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-image: url('public/images/bg.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
            color: #333;
            line-height: 1.6;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        .card {
            background: #fff;
            color: #222;
            border-radius: 16px;
            padding: 1.5rem;
            margin-bottom: 2rem;
            box-shadow: 0 8px 32px 0 #3a86ff22, 0 1.5px 8px 0 #0002;
            border: 1.5px solid #3a86ff33;
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .card-header h2 {
            font-weight: 700;
            font-size: 1.7rem;
            color: #37433bff;
            display: flex;
            align-items: center;
            letter-spacing: 1px;
            text-shadow: 0 4px 24px #3a86ff22, 0 1px 0 #2221;
            position: relative;
            z-index: 1;
        }
        .card-header h2::after {
            content: none;
        }

        .card-header h2 i,
        .action-btn i,
        .back-link i {
            color: #37433bff !important;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
            color: #222;
        }

        th {
            font-weight: 500;
            color: #37433bff;
            text-transform: uppercase;
            font-size: 0.75rem;
            letter-spacing: 0.5px;
        }

        tr:hover td {
            background-color: #f0f8ff;
            color: #222;
        }

        .badge {
            display: inline-block;
            padding: 0.35rem 0.75rem;
            border-radius: 50px;
            font-size: 0.75rem;
            font-weight: 500;
        }

        .badge-primary {
            background-color: rgba(58, 134, 255, 0.2);
            color: #3a86ff;
        }

        .badge-success {
            background-color: rgba(35, 209, 96, 0.2);
            color: #23d160;
        }

        .badge-warning {
            background-color: rgba(255, 221, 87, 0.2);
            color: #947600;
        }

        .badge-danger {
            background-color: rgba(255, 56, 96, 0.2);
            color: #ff3860;
        }

        .badge-info {
            background-color: rgba(23, 162, 184, 0.2);
            color: #17a2b8;
        }

        .action-btn, .back-link {
            
            color: #fff !important;
            border: none;
        }

        .action-btn:hover, .back-link:hover {
            background-color: #596a5fff;
            color: #fff !important;
            transform: translateY(-2px);
        }

        .action-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background-color: #e0eaff;
            color: #000 !important;
            margin-right: 0.5rem;
            transition: var(--transition);
            border: none;
            cursor: pointer;
            font-size: 1.1rem;
        }

        .action-btn:hover {
            background-color: #b3d1ff;
            color: #000 !important;
            transform: translateY(-2px);
        }

        .action-btn.view {
            background-color: rgba(35, 209, 96, 0.2);
            color: var(--success);
        }

        .action-btn.edit {
            background-color: rgba(255, 221, 87, 0.2);
            color: #947600;
        }

        .action-btn.delete {
            background-color: rgba(255, 56, 96, 0.2);
            color: var(--danger);
        }

        .action-btn.activate {
            background-color: rgba(35, 209, 96, 0.2);
            color: var(--success);
        }

        .action-btn.deactivate {
            background-color: rgba(255, 56, 96, 0.2);
            color: var(--danger);
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            padding: 0.75rem 1.5rem;
            border-radius: var(--border-radius);
            background-color: var(--primary);
            color: white;
            text-decoration: none;
            font-weight: 500;
            transition: var(--transition);
            margin-top: 1.5rem;
        }

        .back-link:hover {
            background-color: #596a5fff;
            transform: translateY(-2px);
        }

        .back-link i {
            margin-right: 0.5rem;
        }

        .permission-badge {
            display: inline-block;
            padding: 0.25rem 0.5rem;
            margin: 0.1rem;
            border-radius: 3px;
            font-size: 0.7rem;
            background-color: #e0eaff;
            color: #222;
        }

        .status-badge {
            display: inline-block;
            padding: 0.35rem 0.75rem;
            border-radius: 50px;
            font-size: 0.75rem;
            font-weight: 500;
            min-width: 70px;
            text-align: center;
        }

        .status-active {
            background-color: #e0ffe6;
            color: #23d160;
        }

        .status-inactive {
            background-color: #ffe0e6;
            color: #ff3860;
        }

        .deletion-warning {
            color: #ffdd57;
            font-size: 0.8rem;
            margin-top: 0.2rem;
            display: block;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h2><i class="fas fa-users-cog"></i>  Staff Activity</h2>
            </div>
            <div class="card-body">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Permissions</th>
                            <th>Created At</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($row = $users->fetch_assoc()): 
                            $status = isset($row['status']) ? $row['status'] : 'active';
                            $deactivationDate = isset($row['deactivation_date']) ? $row['deactivation_date'] : null;
                            $scheduledDeletion = ($status == 'inactive' && $deactivationDate) ? 'Scheduled for deletion on: ' . $deactivationDate : '';
                        ?>
                        <tr>
                            <td><?= $row['id'] ?></td>
                            <td><?= htmlspecialchars($row['username']) ?></td>
                            <td>
                                <span class="badge
                                    <?= $row['role'] == 'admin' ? 'badge-primary' : '' ?>
                                    <?= $row['role'] == 'staff' ? 'badge-warning' : '' ?>
                                   
                                ">
                                    <?php
                                        if ($row['role'] == 'staff' || $row['role'] == 'staff') {
                                            echo 'Staff';
                                       
                                        } elseif ($row['role'] == 'admin') {
                                            echo 'Admin';
                                        } else {
                                            echo ucfirst(htmlspecialchars($row['role']));
                                        }
                                    ?>
                                </span>
                            </td>
                            <td>
                                <span class="status-badge status-<?= $status ?>">
                                    <?= ucfirst($status) ?>
                                </span>
                                <?php if ($scheduledDeletion): ?>
                                <span class="deletion-warning"><?= $scheduledDeletion ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php 
                                $perms = isset($row['permissions']) ? explode(',', $row['permissions']) : [];
                                foreach($perms as $perm): ?>
                                    <span class="permission-badge"><?= htmlspecialchars($perm) ?></span>
                                <?php endforeach; ?>
                            </td>
                            <td><?= isset($row['created_at']) ? htmlspecialchars($row['created_at']) : 'N/A' ?></td>
                            <td>
                                <a href="view_user.php?id=<?= $row['id'] ?>" class="action-btn view" title="View">
                                    <i class="fas fa-user"></i>
                                </a>
                                <?php if (in_array('update', $permissions)): ?>
                                <a href="edit.php?id=<?= $row['id'] ?>" class="action-btn edit" title="Edit">
                                    <i class="fas fa-pen"></i>
                                </a>
                                
                                <?php if ($status == 'active'): ?>
                                <a href="?action=deactivate&id=<?= $row['id'] ?>" class="action-btn deactivate" title="Deactivate" onclick="return confirm('Deactivate this user? Account will be deleted after 3 days.')">
                                    <i class="fas fa-user-xmark"></i>
                                </a>
                                <?php else: ?>
                                <a href="?action=activate&id=<?= $row['id'] ?>" class="action-btn activate" title="Activate" onclick="return confirm('Activate this user?')">
                                    <i class="fas fa-user-check"></i>
                                </a>
                                <?php endif; ?>
                                <?php endif; ?>
                                
                                <?php if (in_array('delete', $permissions)): ?>
                                <a href="delete.php?id=<?= $row['id'] ?>" class="action-btn delete" title="Delete" onclick="return confirm('Are you sure? This will permanently delete the user.')">
                                    <i class="fas fa-user-minus"></i>
                                </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <a href="dashboard.php" class="back-link">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
    </div>
</body>
</html>