<?php
session_start();
require_once __DIR__ . '/vendor/autoload.php';
include 'db.php';

use RobThree\Auth\Providers\Qr\GoogleChartsQrCodeProvider;
use RobThree\Auth\TwoFactorAuth;

if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

$username = $_SESSION['username'];
$stmt = $conn->prepare("SELECT otp_secret FROM users WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

$tfa = new TwoFactorAuth(new GoogleChartsQrCodeProvider(), 'RBAC System');
$secret = $user['otp_secret'];
$qrCodeUrl = $tfa->getQRCodeImageAsDataUri($username, $secret);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>OTP Container</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: #f5f5f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .otp-container {
            background: #fff;
            padding: 40px 32px;
            border-radius: 18px;
            box-shadow: 0 8px 32px 0 #4361ee22, 0 1.5px 8px 0 #0002;
            border: 1.5px solid #4361ee33;
            text-align: center;
            max-width: 400px;
        }
        .otp-container h2 {
            margin-bottom: 18px;
            color: #222;
        }
        .otp-container img {
            margin-bottom: 18px;
            width: 180px;
            height: 180px;
        }
        .otp-secret {
            font-size: 1.2rem;
            color: #4361ee;
            background: #f5f5f5;
            padding: 8px 16px;
            border-radius: 8px;
            margin-bottom: 18px;
            display: inline-block;
        }
        .instructions {
            font-size: 1rem;
            color: #333;
            margin-bottom: 12px;
        }
    </style>
</head>
<body>
    <div class="otp-container">
        <h2>Your OTP Setup</h2>
        <img src="<?= $qrCodeUrl ?>" alt="QR Code">
        <div class="otp-secret">Secret: <?= $secret ?></div>
        <div class="instructions">
            <strong>How to use:</strong><br>
            1. Open your authenticator app (Google Authenticator, Authy, etc).<br>
            2. Tap '+' to add a new account.<br>
            3. Scan the QR code above or enter the secret manually.<br>
            4. Enter the generated 6-digit code in the login form.<br>
            <br>
            <em>Only OTP code is required for login.</em>
        </div>
    </div>
</body>
</html>
