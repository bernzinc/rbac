<?php
session_start();

// Check login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Check if user has 'read' permission
if (!in_array('read', $_SESSION['permissions'] ?? [])) {
    echo "<h3 style='text-align:center; color:red;'>❌ Access denied. You do not have permission to view user details.</h3>";
    exit();
}

include 'db.php';

$id = $_GET['id'] ?? 0;

$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Employee | Employee Monitoring System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #4361ee;
            --dark: #212529;
            --light: #f8f9fa;
            --gray: #6c757d;
            --gray-light: #e9ecef;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background: url('public/images/bg.jpg') no-repeat center center fixed;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            padding: 1rem;
        }
        
        .card {
            background: #fff;
            color: #222;
            border-radius: 16px;
            box-shadow: 0 8px 32px 0 #4361ee55, 0 1.5px 8px 0 #0008;
            padding: 2rem;
            width: 100%;
            max-width: 440px;
            animation: fadeIn 0.4s ease;
            border: 1.5px solid #4361ee33;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .card-title {
            font-size: 1.7rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
            text-align: center;
            color: #37433bff;
            letter-spacing: 1px;
            text-shadow: 0 4px 24px #4361ee22, 0 1px 0 #2221;
            position: relative;
            z-index: 1;
        }
        .card-title::after {
            content: none;
        }
        
        .info-row {
            display: flex;
            margin-bottom: 1rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .info-label {
            width: 120px;
            font-weight: 500;
            color: #555;
        }
        
        .info-value {
            flex: 1;
            font-weight: 400;
            word-break: break-word;
            color: #222;
        }
        
        .not-found {
            text-align: center;
            color: #ff6b6b;
            margin: 1rem 0;
        }
        
        .btn-back {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 95%;
            padding: 0.75rem;
            margin-top: 1.5rem;
            background-color: #6D8474;
            color: white;
            text-align: center;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 500;
            transition: background-color 0.2s;
        }
        
        .btn-back:hover {
            background-color: #596a5fff;
        }
        
        .permission-badge {
            display: inline-block;
            padding: 0.25rem 0.5rem;
            background-color: rgba(9, 81, 49, 0.2);
            border-radius: 4px;
            margin-right: 0.5rem;
            margin-bottom: 0.5rem;
            font-size: 0.8rem;
        }
    </style>
</head>
<body>
    <div class="card">
        <h2 class="card-title">Staff Details</h2>

        <?php if ($user): ?>
            <div class="info-row">
                <div class="info-label">Staff</div>
                <div class="info-value"><?= htmlspecialchars($user['username']) ?></div>
            </div>

            <div class="info-row">
                <div class="info-label">Role</div>
                <div class="info-value">
                    <?php
                        if ($user['role'] === 'employee' || $user['role'] === 'staff') {
                            echo 'Staff';
                        } elseif ($user['role'] === 'manager') {
                            echo 'Manager';
                        } elseif ($user['role'] === 'admin') {
                            echo 'Admin';
                        } else {
                            echo htmlspecialchars(ucfirst($user['role']));
                        }
                    ?>
                </div>
            </div>

            <div class="info-row">
                <div class="info-label">Permissions</div>
                <div class="info-value">
                    <?php if ($user['permissions']): ?>
                        <?php foreach(explode(',', $user['permissions']) as $perm): ?>
                            <span class="permission-badge"><?= htmlspecialchars($perm) ?></span>
                        <?php endforeach; ?>
                    <?php else: ?>
                        None
                    <?php endif; ?>
                </div>
            </div>

            <div class="info-row">
                <div class="info-label">Added By</div>
                <div class="info-value"><?= htmlspecialchars($user['created_by'] ?? 'System') ?></div>
            </div>

            <div class="info-row" style="border-bottom: none;">
                <div class="info-label">Added At</div>
                <div class="info-value"><?= htmlspecialchars($user['created_at'] ?? 'N/A') ?></div>
            </div>
        <?php else: ?>
            <p class="not-found">❌ Staff not found</p>
        <?php endif; ?>

        <a href="dashboard.php" class="btn-back">Back to Dashboard</a>
    </div>
</body>
</html>