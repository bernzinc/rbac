<?php  
session_start();
include 'db.php';


$disableLoginButton = false;
$remainingTime = 0;
$remainingAttempts = 3;

if (isset($_SESSION['login_attempts'])) {
    $remainingAttempts = max(0, 3 - $_SESSION['login_attempts']);
    
    if ($_SESSION['login_attempts'] >= 3) {
        if (!isset($_SESSION['lockout_time'])) {
            $_SESSION['lockout_time'] = time() + 60; // 1 minute lockout
        }
        
        $remainingTime = $_SESSION['lockout_time'] - time();
        
        if ($remainingTime > 0) {
            $disableLoginButton = true;
        } else {
            // Lockout period over, reset attempts
            unset($_SESSION['login_attempts']);
            unset($_SESSION['lockout_time']);
        }
    }
}

// After verifying credentials but before allowing login:
if (isset($_POST['username'])) {
    $username = $_POST['username'];
    $stmt = $conn->prepare("SELECT status FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if ($user['status'] === 'inactive') {
            die("Account disabled. Contact admin.");
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            background: url('public/images/bg.jpg') no-repeat center center fixed;
            background-size: cover;
            color: #1c1c1c;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .login-container {
            background: #fff;
            color: #222;
            padding: 48px 36px;
            border-radius: 22px;
            max-width: 400px;
            width: 100%;
            box-shadow: 0 8px 32px 0 #4361ee22, 0 1.5px 8px 0 #0002;
            transition: all 0.3s ease;
            border: 1.5px solid #4361ee33;
        }

        .login-icon {
            font-size: 50px;
            text-align: center;
            margin-bottom: 20px;
        }

        h2 {
            text-align: center;
            color: #37433bff;
            margin-bottom: 30px;
            font-weight: 700;
            font-size: 28px;
            position: relative;
            z-index: 1;
            text-shadow: none;
            letter-spacing: 1px;
        }
        h2::after {
            content: none;
        }

        .input-group {
            display: flex;
            align-items: center;
            background: #f5f5f5;
            border-radius: 12px;
            margin: 15px 0;
            padding: 0 14px;
            transition: 0.3s ease;
        }

        .input-group i {
            color: #6D8474;
            font-size: 18px;
        }

        .input-group input {
            flex: 1;
            background: transparent;
            border: none;
            color: #222;
            padding: 14px 10px;
            font-size: 15px;
        }

        .input-group input:focus {
            outline: none;
        }

        .input-group:focus-within {
            background-color: #e3e3e3;
            box-shadow: 0 0 0 2px #4361ee;
        }

        button {
            margin-top: 25px;
            width: 100%;
            padding: 14px;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: bold;
            color: #fff;
            background: #6D8474;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        button:hover:not(:disabled) {
            background: #5d7365ff;
        }

        button:disabled {
            background: #444;
            cursor: not-allowed;
        }

        .error {
            background: rgba(255, 76, 76, 0.15);
            color: #ff4c4c;
            border-left: 4px solid #ff4c4c;
            padding: 12px 14px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
        }

        .attempts-info {
            color: #ff9800;
            margin-top: 10px;
            font-size: 14px;
            text-align: center;
        }

        .countdown {
            color: #ff5722;
            font-weight: bold;
        }

        @media (max-width: 500px) {
            .login-container {
                padding: 30px 20px;
                margin: 10px;
            }
        }
        
        .logo {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 28px;
            gap: 12px;
        }
        .logo-img {
            height: 48px;
            width: 48px;
            object-fit: contain;
            border-radius: 8px;
            background: #fff;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }
        .logo-text {
            font-size: 1.7rem;
            font-weight: 600;
            color: #fff;
            letter-spacing: 1px;
        }
    </style>
</head>
<body>
    <div class="login-container"> 
        <!-- Logo removed as requested -->
        <h2>Role Based Access Control</h2>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="error"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
        <?php endif; ?>

        <form method="POST" action="login_process.php" id="loginForm">
            <div class="input-group">
                <i class="fas fa-user"></i>
                <input type="text" name="username" placeholder="Username" required>
            </div>
            <div class="input-group">
                <i class="fas fa-lock"></i>
                <input type="password" name="password" placeholder="Password" required>
            </div>
            <button type="submit" <?= $disableLoginButton ? 'disabled' : '' ?>>Login</button>
            <?php if ($disableLoginButton): ?>
                <div class="attempts-info">
                    Account locked. Please wait <span class="countdown" id="countdown"><?= $remainingTime ?></span> seconds.
                </div>
            <?php elseif ($remainingAttempts < 3): ?>
                <div class="attempts-info">
                    Remaining attempts: <?= $remainingAttempts ?>
                </div>
            <?php endif; ?>
        </form>
    </div>

    <?php if ($disableLoginButton): ?>
    <script>
        function updateCountdown() {
            var countdown = document.getElementById('countdown');
            var seconds = parseInt(countdown.textContent);
            if (seconds > 1) {
                seconds--;
                countdown.textContent = seconds;
                setTimeout(updateCountdown, 1000);
            } else {
                location.reload();
            }
        }
        updateCountdown();
    </script>
    <?php endif; ?>
</body>
</html>