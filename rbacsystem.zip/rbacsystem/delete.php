<?php
session_start();
include 'db.php';

$id = $_GET['id'];

// Get user info before deleting
$result = $conn->query("SELECT username FROM users WHERE id = $id");
$user = $result->fetch_assoc();

if ($user) {
    if ($conn->query("DELETE FROM users WHERE id = $id")) {
        // Log the deletion
        log_action($conn, $_SESSION['username'], 'Success', 'Delete User', 
                  "Deleted user '{$user['username']}' (ID: $id)");
    } else {
        // Log the failure
        log_action($conn, $_SESSION['username'], 'Failed', 'Delete User', "Failed to delete user '{$user['username']}' (ID: $id): " . $conn->error);
    }
}

header("Location: view.php");
exit();
?>