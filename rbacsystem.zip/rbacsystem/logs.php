<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Check if user has 'read' permission
if (!in_array('read', $_SESSION['permissions'] ?? [])) {
    echo "<h3 style='text-align:center; color:red;'>❌ Access denied. You do not have permission to view logs.</h3>";
    exit();
}

include 'db.php';

// Get all logs
$logs = $conn->query("SELECT * FROM system_logs ORDER BY timestamp DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Logs | Employee Monitoring System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #3a86ff;
            --danger: #ff3860;
            --success: #23d160;
            --warning: #ffdd57;
            --dark: #1a1a1a;
            --light: #f8f9fa;
            --border-radius: 12px;
            --shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-image: url('public/images/bg.jpg');
            color: #000;
            line-height: 1.6;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: #fff;
            color: #000;
            border-radius: 16px;
            box-shadow: 0 8px 32px 0 #3a86ff22, 0 1.5px 8px 0 #0002;
            padding: 2rem 2rem 1rem 2rem;
        }

        .card {
            background: #fff;
            color: #000;
            border-radius: 16px;
            padding: 1.5rem;
            margin-bottom: 2rem;
            box-shadow: none;
            border: 1.5px solid #3a86ff33;
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .card-header h2 {
            font-weight: 700;
            font-size: 1.7rem;
            color: #37433bff;
            display: flex;
            align-items: center;
            letter-spacing: 1px;
            text-shadow: 0 4px 24px #3a86ff22, 0 1px 0 #2221;
            position: relative;
            z-index: 1;
        }
        .card-header h2::after {
            content: none;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
            color: #000;
        }

        th {
            font-weight: 500;
            color: #000;
            text-transform: uppercase;
            font-size: 0.75rem;
            letter-spacing: 0.5px;
        }

        tr:hover td {
            background-color: #f0f8ff;
            color: #000;
        }

        .badge {
            display: inline-block;
            padding: 0.35rem 0.75rem;
            border-radius: 50px;
            font-size: 0.75rem;
            font-weight: 500;
        }

        .badge-success {
            background-color: rgba(35, 209, 96, 0.2);
            color: #23d160;
        }

        .badge-danger {
            background-color: rgba(255, 56, 96, 0.2);
            color: #ff3860;
        }

        .badge-warning {
            background-color: rgba(255, 221, 87, 0.2);
            color: #947600;
        }

        .badge-info {
            background-color: #e0eaff;
            color: #222;
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            padding: 0.75rem 1.5rem;
            border-radius: var(--border-radius);
            background-color: #6D8474;
            color: #fff !important;
            text-decoration: none;
            font-weight: 500;
            transition: var(--transition);
            margin-top: 1.5rem;
            border: none;
        }

        .back-link:hover {
            background-color: #596a5fff;
            color: #fff !important;
            transform: translateY(-2px);
        }

        .back-link i {
            margin-right: 0.5rem;
        }

        .empty-state {
            text-align: center;
            padding: 3rem;
            color: #000;
        }

        .empty-state i {
            font-size: 3rem;
            margin-bottom: 1rem;
            opacity: 0.5;
            color: #000;
        }

        .empty-state h3 {
            font-weight: 500;
            margin-bottom: 0.5rem;
            color: #000;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h2><i class="fas fa-clipboard-list"></i> System Logs</h2>
            </div>
            <div class="card-body">
                <?php if ($logs->num_rows > 0): ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Status</th>
                                <th>Timestamp</th>
                                <th>Action</th>
                                <th>Description</th>
                                <th>IP Address</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($log = $logs->fetch_assoc()): ?>
                                <tr>
                                    <td><?= htmlspecialchars($log['username']) ?></td>
                                    <td>
                                        <span class="badge 
                                            <?= $log['status'] == 'Success' ? 'badge-success' : 'badge-danger' ?>">
                                            <?= htmlspecialchars($log['status']) ?>
                                        </span>
                                    </td>
                                    <td><?= htmlspecialchars($log['timestamp']) ?></td>
                                    <td><?= htmlspecialchars($log['action']) ?></td>
                                    <td><?= htmlspecialchars($log['description']) ?></td>
                                    <td><?= htmlspecialchars($log['ip_address']) ?></td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-clipboard"></i>
                        <h3>No Logs Found</h3>
                        <p>No system activity has been logged yet</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <a href="dashboard.php" class="back-link">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
    </div>
</body>
</html>