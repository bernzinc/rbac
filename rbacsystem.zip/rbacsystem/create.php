<?php
session_start();
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];
    $created_by = $_SESSION['username'];
    
    // Automatically set all permissions for admin
    if ($role == 'admin') {
        $permissions = 'create,read,update,delete';
    } elseif ($role == 'manager' && isset($_POST['permissions'])) {
        $permissions = implode(',', $_POST['permissions']);
    } elseif ($role == 'employee' && isset($_POST['permissions'])) {
        $permissions = implode(',', $_POST['permissions']);
    } else {
        $permissions = '';
    }

    $sql = "INSERT INTO users (username, password, role, created_by, permissions) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("SQL error: " . $conn->error);
    }

    $stmt->bind_param("sssss", $username, $password, $role, $created_by, $permissions);

    if ($stmt->execute()) {
        // Log the user creation
        log_action($conn, $_SESSION['username'], 'Success', 'Create User', 
                  "Created new user '{$username}' with role '{$role}' and permissions: {$permissions}");
        header("Location: dashboard.php");
        exit();
    } else {
        // Log the failure
        log_action($conn, $_SESSION['username'], 'Failed', 'Create User', "Failed to create user '{$username}': " . $conn->error);
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Employee | Employee Monitoring System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #4361ee;
            --dark: #212529;
            --light: #f8f9fa;
            --gray: #6c757d;
            --gray-light: #e9ecef;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background-image: url('public/images/bg.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            padding: 1rem;
        }
        
        .card {
            background: #fff;
            color: #212529;
            border-radius: 16px;
            box-shadow: 0 8px 32px 0 #4361ee22, 0 1.5px 8px 0 #0002;
            padding: 2rem;
            width: 100%;
            max-width: 440px;
            border: 1.5px solid #4361ee33;
        }
        
        .card-title {
            font-size: 1.7rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
            text-align: center;
            color: #37433bff;
            letter-spacing: 1px;
            text-shadow: 0 4px 24px #4361ee33, 0 1px 0 #2221;
            position: relative;
            z-index: 1;
        }
        .card-title::after {
            content: none;
        }
        
        .form-group {
            margin-bottom: 1.25rem;
            
        }
        
        .form-label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: #212529;
        }
        
        .form-control {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            font-size: 0.95rem;
            background-color: rgba(255, 255, 255, 0.05);
            color: white;
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.3);
        }
        
        .checkbox-group {
            display: flex;
            flex-wrap: wrap;
            gap: 0.75rem;
            margin-top: 0.5rem;
        }
        
        .checkbox-item {
            display: flex;
            align-items: center;
            font-size: 0.9rem;
        }
        
        .checkbox-item input {
            margin-right: 0.5rem;
        }

        .checkbox-item input:checked {
            accent-color: #6D8474;
        }
        
        .btn {
            width: 100%;
            padding: 0.75rem;
            border-radius: 8px;
            font-weight: 500;
            cursor: pointer;
            border: none;
            background-color: #6D8474;
            color: white;
            margin-top: 0.5rem;
            transition: background-color 0.2s;
        }
        
        .btn:hover {
            background: #596a5fff;
        }
        
        .back-link {
            display: block;
            text-align: center;
            margin-top: 1rem;
            color: #6D8474 !important;
            font-size: 0.9rem;
            text-decoration: none;
        }
        
        .back-link:hover {
            color: gray;
            text-decoration: underline;
        }
        
        .disabled-checkbox {
            opacity: 0.6;
            pointer-events: none;
        }
    </style>
</head>
<body>
    <div class="card">
        <h2 class="card-title">Add Staff</h2>
        
        <form method="POST">
            <div class="form-group">
                <label for="username" class="form-label">Username</label>
                <input type="text" id="username" name="username" class="form-control" placeholder="Enter username" required>
            </div>
            
            <div class="form-group">
                <label for="password" class="form-label">Password</label>
                <input type="password" id="password" name="password" class="form-control" placeholder="Enter password" required>
            </div>
            
            <div class="form-group">
                <label for="role" class="form-label">Role</label>
                <select id="role" name="role" class="form-control" required onchange="handleRoleChange()">
                    <option value="" disabled selected hidden>Select Role (Admin or Staff)</option>
                    <option value="admin">Admin</option>
                    <option value="staff">Staff</option>
                  
                </select>
            </div>
            
            <div class="form-group">
                <label class="form-label">Permissions</label>
                <div class="checkbox-group" id="permissions-container">
                    <label class="checkbox-item">
                        <input type="checkbox" name="permissions[]" value="create" id="create"> Create
                    </label>
                    <label class="checkbox-item">
                        <input type="checkbox" name="permissions[]" value="read" id="read"> Read
                    </label>
                    <label class="checkbox-item">
                        <input type="checkbox" name="permissions[]" value="update" id="update"> Update
                    </label>
                    <label class="checkbox-item">
                        <input type="checkbox" name="permissions[]" value="delete" id="delete"> Delete
                    </label>
                </div>
            </div>
            
            <button type="submit" class="btn">Add Staff</button>
            <a href="dashboard.php" class="back-link">Back to Dashboard</a>
        </form>
    </div>

    <script>
        function handleRoleChange() {
            const roleSelect = document.getElementById('role');
            const checkboxes = document.querySelectorAll('#permissions-container input[type="checkbox"]');
            
            if (roleSelect.value === 'admin') {
                // Auto-check all permissions for admin and disable the checkboxes
                checkboxes.forEach(checkbox => {
                    checkbox.checked = true;
                    checkbox.classList.add('disabled-checkbox');
                });
            } else {
                // For staff, uncheck all and enable checkboxes
                checkboxes.forEach(checkbox => {
                    checkbox.checked = false;
                    checkbox.classList.remove('disabled-checkbox');
                });
            }
        }
        
        // Initialize on page load in case of form resubmission
        document.addEventListener('DOMContentLoaded', function() {
            handleRoleChange();
        });
    </script>
</body>
</html>